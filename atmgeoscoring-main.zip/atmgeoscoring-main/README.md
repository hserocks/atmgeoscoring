# atmgeoscorint

docker compose up


